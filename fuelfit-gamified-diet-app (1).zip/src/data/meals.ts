export interface Dish {
  id: string;
  name: string;
  emoji: string;
  baseCalories: number; // per 100g
  protein: number; // per 100g
  carbs: number; // per 100g
  fat: number; // per 100g
  defaultGrams: number;
  category: 'breakfast' | 'lunch' | 'dinner' | 'snack';
}

export const breakfastDishes: Dish[] = [
  { id: 'b1', name: 'Овсянка на воде', emoji: '🥣', baseCalories: 88, protein: 3, carbs: 15, fat: 1.7, defaultGrams: 250, category: 'breakfast' },
  { id: 'b2', name: 'Яичница (2 яйца)', emoji: '🍳', baseCalories: 196, protein: 13.6, carbs: 0.7, fat: 15.3, defaultGrams: 120, category: 'breakfast' },
  { id: 'b3', name: 'Творог 5%', emoji: '🧀', baseCalories: 121, protein: 17.2, carbs: 1.8, fat: 5, defaultGrams: 180, category: 'breakfast' },
  { id: 'b4', name: 'Бутерброд с сыром', emoji: '🥪', baseCalories: 280, protein: 11, carbs: 26, fat: 14, defaultGrams: 100, category: 'breakfast' },
  { id: 'b5', name: 'Йогурт натуральный', emoji: '🥛', baseCalories: 60, protein: 4, carbs: 6, fat: 1.5, defaultGrams: 200, category: 'breakfast' },
  { id: 'b6', name: 'Каша гречневая', emoji: '🥣', baseCalories: 110, protein: 4.5, carbs: 21, fat: 1.1, defaultGrams: 200, category: 'breakfast' },
  { id: 'b7', name: 'Блинчики (2 шт)', emoji: '🥞', baseCalories: 233, protein: 6.1, carbs: 32, fat: 8.4, defaultGrams: 120, category: 'breakfast' },
  { id: 'b8', name: 'Омлет с овощами', emoji: '🥚', baseCalories: 130, protein: 9.6, carbs: 2.1, fat: 9.3, defaultGrams: 180, category: 'breakfast' },
  { id: 'b9', name: 'Рисовая каша', emoji: '🍚', baseCalories: 97, protein: 2.5, carbs: 17, fat: 2, defaultGrams: 250, category: 'breakfast' },
  { id: 'b10', name: 'Сырники (3 шт)', emoji: '🧈', baseCalories: 183, protein: 14.4, carbs: 15.8, fat: 7.2, defaultGrams: 150, category: 'breakfast' },
];

export const lunchDishes: Dish[] = [
  { id: 'l1', name: 'Куриная грудка варёная', emoji: '🍗', baseCalories: 137, protein: 29.8, carbs: 0.5, fat: 1.8, defaultGrams: 200, category: 'lunch' },
  { id: 'l2', name: 'Гречка с курицей', emoji: '🍛', baseCalories: 115, protein: 12, carbs: 13, fat: 2.5, defaultGrams: 300, category: 'lunch' },
  { id: 'l3', name: 'Щи из свежей капусты', emoji: '🥣', baseCalories: 31, protein: 1, carbs: 3.8, fat: 1.2, defaultGrams: 350, category: 'lunch' },
  { id: 'l4', name: 'Рис с овощами', emoji: '🍚', baseCalories: 108, protein: 2.6, carbs: 19.5, fat: 2.4, defaultGrams: 250, category: 'lunch' },
  { id: 'l5', name: 'Макароны с фаршем', emoji: '🍝', baseCalories: 160, protein: 8, carbs: 19, fat: 5.5, defaultGrams: 280, category: 'lunch' },
  { id: 'l6', name: 'Салат из свежих овощей', emoji: '🥗', baseCalories: 32, protein: 1.2, carbs: 5.1, fat: 0.5, defaultGrams: 200, category: 'lunch' },
  { id: 'l7', name: 'Суп куриный с лапшой', emoji: '🍜', baseCalories: 45, protein: 3.5, carbs: 4.2, fat: 1.5, defaultGrams: 350, category: 'lunch' },
  { id: 'l8', name: 'Картофельное пюре', emoji: '🥔', baseCalories: 100, protein: 2, carbs: 16, fat: 3.5, defaultGrams: 200, category: 'lunch' },
  { id: 'l9', name: 'Рыба запечённая', emoji: '🐟', baseCalories: 114, protein: 20, carbs: 0, fat: 3.5, defaultGrams: 180, category: 'lunch' },
  { id: 'l10', name: 'Котлеты куриные (2 шт)', emoji: '🥩', baseCalories: 145, protein: 18, carbs: 5, fat: 5.8, defaultGrams: 160, category: 'lunch' },
  { id: 'l11', name: 'Борщ', emoji: '🍲', baseCalories: 49, protein: 1.8, carbs: 5.5, fat: 2.2, defaultGrams: 350, category: 'lunch' },
  { id: 'l12', name: 'Плов с курицей', emoji: '🍛', baseCalories: 150, protein: 10, carbs: 18, fat: 4.5, defaultGrams: 280, category: 'lunch' },
];

export const dinnerDishes: Dish[] = [
  { id: 'd1', name: 'Куриная грудка на пару', emoji: '🍗', baseCalories: 113, protein: 23.6, carbs: 0, fat: 1.9, defaultGrams: 180, category: 'dinner' },
  { id: 'd2', name: 'Овощное рагу', emoji: '🥘', baseCalories: 55, protein: 1.5, carbs: 7.5, fat: 2, defaultGrams: 300, category: 'dinner' },
  { id: 'd3', name: 'Салат с тунцом', emoji: '🥗', baseCalories: 89, protein: 10, carbs: 3, fat: 4, defaultGrams: 220, category: 'dinner' },
  { id: 'd4', name: 'Творожная запеканка', emoji: '🍮', baseCalories: 168, protein: 15, carbs: 14, fat: 6, defaultGrams: 200, category: 'dinner' },
  { id: 'd5', name: 'Рыба с овощами', emoji: '🐟', baseCalories: 90, protein: 12, carbs: 5, fat: 2.5, defaultGrams: 250, category: 'dinner' },
  { id: 'd6', name: 'Гречка с грибами', emoji: '🍄', baseCalories: 105, protein: 5, carbs: 15, fat: 2.8, defaultGrams: 250, category: 'dinner' },
  { id: 'd7', name: 'Куриный суп лёгкий', emoji: '🥣', baseCalories: 40, protein: 3.5, carbs: 3, fat: 1.5, defaultGrams: 350, category: 'dinner' },
  { id: 'd8', name: 'Омлет белковый', emoji: '🥚', baseCalories: 85, protein: 12, carbs: 0.5, fat: 4, defaultGrams: 200, category: 'dinner' },
  { id: 'd9', name: 'Капустный салат', emoji: '🥬', baseCalories: 28, protein: 1.8, carbs: 4.7, fat: 0.1, defaultGrams: 200, category: 'dinner' },
  { id: 'd10', name: 'Индейка запечённая', emoji: '🦃', baseCalories: 130, protein: 25, carbs: 0, fat: 3, defaultGrams: 180, category: 'dinner' },
];

export const snackDishes: Dish[] = [
  { id: 's1', name: 'Яблоко', emoji: '🍎', baseCalories: 52, protein: 0.3, carbs: 13.8, fat: 0.2, defaultGrams: 180, category: 'snack' },
  { id: 's2', name: 'Банан', emoji: '🍌', baseCalories: 89, protein: 1.1, carbs: 22.8, fat: 0.3, defaultGrams: 120, category: 'snack' },
  { id: 's3', name: 'Орехи (миндаль)', emoji: '🥜', baseCalories: 579, protein: 21, carbs: 21, fat: 49, defaultGrams: 30, category: 'snack' },
  { id: 's4', name: 'Кефир 1%', emoji: '🥛', baseCalories: 40, protein: 3, carbs: 4, fat: 1, defaultGrams: 250, category: 'snack' },
  { id: 's5', name: 'Морковные палочки', emoji: '🥕', baseCalories: 35, protein: 0.8, carbs: 6.9, fat: 0.2, defaultGrams: 150, category: 'snack' },
  { id: 's6', name: 'Апельсин', emoji: '🍊', baseCalories: 43, protein: 0.9, carbs: 8.1, fat: 0.2, defaultGrams: 200, category: 'snack' },
  { id: 's7', name: 'Сухофрукты', emoji: '🍇', baseCalories: 264, protein: 2.5, carbs: 68, fat: 0.5, defaultGrams: 40, category: 'snack' },
  { id: 's8', name: 'Хлебцы цельнозерновые', emoji: '🍞', baseCalories: 313, protein: 10, carbs: 57, fat: 4.5, defaultGrams: 40, category: 'snack' },
  { id: 's9', name: 'Творожок детский', emoji: '🧁', baseCalories: 103, protein: 8, carbs: 12, fat: 2.5, defaultGrams: 100, category: 'snack' },
  { id: 's10', name: 'Груша', emoji: '🍐', baseCalories: 47, protein: 0.4, carbs: 10.3, fat: 0.1, defaultGrams: 180, category: 'snack' },
];

export function getDishCalories(dish: Dish, grams?: number): number {
  const g = grams ?? dish.defaultGrams;
  return Math.round((dish.baseCalories * g) / 100);
}

export function getDishMacros(dish: Dish, grams?: number) {
  const g = grams ?? dish.defaultGrams;
  return {
    calories: Math.round((dish.baseCalories * g) / 100),
    protein: Math.round((dish.protein * g) / 100 * 10) / 10,
    carbs: Math.round((dish.carbs * g) / 100 * 10) / 10,
    fat: Math.round((dish.fat * g) / 100 * 10) / 10,
  };
}
