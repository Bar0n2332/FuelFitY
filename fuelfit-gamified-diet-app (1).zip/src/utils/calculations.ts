export type Goal = 'lose' | 'maintain' | 'gain';
export type Gender = 'male' | 'female';
export type ActivityLevel = 'sedentary' | 'light' | 'moderate' | 'active';

export interface UserProfile {
  name: string;
  gender: Gender;
  age: number;
  height: number; // cm
  weight: number; // kg
  goal: Goal;
  activity: ActivityLevel;
}

export function calculateBMR(profile: UserProfile): number {
  if (profile.gender === 'male') {
    return 10 * profile.weight + 6.25 * profile.height - 5 * profile.age + 5;
  }
  return 10 * profile.weight + 6.25 * profile.height - 5 * profile.age - 161;
}

export function getActivityMultiplier(activity: ActivityLevel): number {
  switch (activity) {
    case 'sedentary': return 1.2;
    case 'light': return 1.375;
    case 'moderate': return 1.55;
    case 'active': return 1.725;
  }
}

export function calculateTDEE(profile: UserProfile): number {
  const bmr = calculateBMR(profile);
  return Math.round(bmr * getActivityMultiplier(profile.activity));
}

export function calculateTargetCalories(profile: UserProfile): number {
  const tdee = calculateTDEE(profile);
  switch (profile.goal) {
    case 'lose': return Math.max(1200, Math.round(tdee - 500));
    case 'gain': return Math.round(tdee + 400);
    case 'maintain': return tdee;
  }
}

export function calculateMacros(targetCalories: number, goal: Goal) {
  let proteinPct: number, carbsPct: number, fatPct: number;

  switch (goal) {
    case 'lose':
      proteinPct = 0.35;
      carbsPct = 0.35;
      fatPct = 0.30;
      break;
    case 'gain':
      proteinPct = 0.30;
      carbsPct = 0.45;
      fatPct = 0.25;
      break;
    case 'maintain':
    default:
      proteinPct = 0.30;
      carbsPct = 0.40;
      fatPct = 0.30;
      break;
  }

  return {
    protein: Math.round((targetCalories * proteinPct) / 4),
    carbs: Math.round((targetCalories * carbsPct) / 4),
    fat: Math.round((targetCalories * fatPct) / 9),
  };
}

export function getMealCalorieDistribution(targetCalories: number) {
  return {
    breakfast: Math.round(targetCalories * 0.25),
    snack1: Math.round(targetCalories * 0.10),
    lunch: Math.round(targetCalories * 0.35),
    snack2: Math.round(targetCalories * 0.10),
    dinner: Math.round(targetCalories * 0.20),
  };
}

export function calculateLevel(totalPoints: number): { level: number; title: string; progress: number; pointsInLevel: number; pointsNeeded: number } {
  const levels = [
    { threshold: 0, title: 'Новичок 🌱' },
    { threshold: 100, title: 'Начинающий 🌿' },
    { threshold: 300, title: 'Ученик 💪' },
    { threshold: 600, title: 'Любитель 🔥' },
    { threshold: 1000, title: 'Знаток 🏋️' },
    { threshold: 1500, title: 'Опытный 🌟' },
    { threshold: 2500, title: 'Мастер 🏆' },
    { threshold: 4000, title: 'Эксперт 👑' },
    { threshold: 6000, title: 'Легенда ⭐' },
    { threshold: 10000, title: 'Чемпион 🏅' },
  ];

  let level = 0;
  for (let i = levels.length - 1; i >= 0; i--) {
    if (totalPoints >= levels[i].threshold) {
      level = i;
      break;
    }
  }

  const currentThreshold = levels[level].threshold;
  const nextThreshold = level < levels.length - 1 ? levels[level + 1].threshold : levels[level].threshold + 5000;
  const pointsInLevel = totalPoints - currentThreshold;
  const pointsNeeded = nextThreshold - currentThreshold;
  const progress = Math.min(1, pointsInLevel / pointsNeeded);

  return {
    level: level + 1,
    title: levels[level].title,
    progress,
    pointsInLevel,
    pointsNeeded,
  };
}

export function getPointsForMeal(mealType: string): number {
  switch (mealType) {
    case 'breakfast': return 15;
    case 'lunch': return 20;
    case 'dinner': return 15;
    case 'snack1':
    case 'snack2': return 10;
    default: return 10;
  }
}

export function getStreakBonus(streak: number): number {
  if (streak >= 30) return 50;
  if (streak >= 14) return 35;
  if (streak >= 7) return 25;
  if (streak >= 3) return 15;
  return 0;
}
