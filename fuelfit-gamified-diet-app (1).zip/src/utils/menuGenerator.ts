import {
  Dish,
  breakfastDishes,
  lunchDishes,
  dinnerDishes,
  snackDishes,
  getDishCalories,
} from '../data/meals';
import { getMealCalorieDistribution } from './calculations';

function seededRandom(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    return (s >>> 0) / 0xffffffff;
  };
}

function pickRandom<T>(arr: T[], rng: () => number): T {
  return arr[Math.floor(rng() * arr.length)];
}

function adjustGrams(dish: Dish, targetCalories: number): { dish: Dish; grams: number } {
  if (dish.baseCalories === 0) return { dish, grams: dish.defaultGrams };
  const grams = Math.round((targetCalories / dish.baseCalories) * 100);
  const clamped = Math.max(50, Math.min(500, grams));
  // Round to nearest 10
  const rounded = Math.round(clamped / 10) * 10;
  return { dish, grams: rounded };
}

export interface MealPlan {
  breakfast: { dish: Dish; grams: number };
  snack1: { dish: Dish; grams: number };
  lunch: { dish: Dish; grams: number }[];
  snack2: { dish: Dish; grams: number };
  dinner: { dish: Dish; grams: number };
}

export function generateDayMenu(targetCalories: number, seed: number): MealPlan {
  const rng = seededRandom(seed);
  const dist = getMealCalorieDistribution(targetCalories);

  const breakfast = adjustGrams(pickRandom(breakfastDishes, rng), dist.breakfast);
  const snack1 = adjustGrams(pickRandom(snackDishes, rng), dist.snack1);

  // Lunch: main + side/salad
  const lunchMain = pickRandom(lunchDishes.filter(d =>
    ['l1', 'l2', 'l5', 'l9', 'l10', 'l12'].includes(d.id)
  ), rng);
  const lunchSide = pickRandom(lunchDishes.filter(d =>
    ['l3', 'l4', 'l6', 'l7', 'l8', 'l11'].includes(d.id) && d.id !== lunchMain.id
  ), rng);

  const lunchMainCal = Math.round(dist.lunch * 0.6);
  const lunchSideCal = Math.round(dist.lunch * 0.4);

  const lunch = [
    adjustGrams(lunchMain, lunchMainCal),
    adjustGrams(lunchSide, lunchSideCal),
  ];

  let snackPool = snackDishes.filter(d => d.id !== snack1.dish.id);
  if (snackPool.length === 0) snackPool = snackDishes;
  const snack2 = adjustGrams(pickRandom(snackPool, rng), dist.snack2);

  const dinner = adjustGrams(pickRandom(dinnerDishes, rng), dist.dinner);

  return { breakfast, snack1, lunch, snack2, dinner };
}

export function getMealTotalCalories(plan: MealPlan): number {
  let total = 0;
  total += getDishCalories(plan.breakfast.dish, plan.breakfast.grams);
  total += getDishCalories(plan.snack1.dish, plan.snack1.grams);
  for (const item of plan.lunch) {
    total += getDishCalories(item.dish, item.grams);
  }
  total += getDishCalories(plan.snack2.dish, plan.snack2.grams);
  total += getDishCalories(plan.dinner.dish, plan.dinner.grams);
  return total;
}

export type MealType = 'breakfast' | 'snack1' | 'lunch' | 'snack2' | 'dinner';

export const mealTypeLabels: Record<MealType, string> = {
  breakfast: '🌅 Завтрак',
  snack1: '🍎 Перекус 1',
  lunch: '☀️ Обед',
  snack2: '🍊 Перекус 2',
  dinner: '🌙 Ужин',
};

export const mealTypeOrder: MealType[] = ['breakfast', 'snack1', 'lunch', 'snack2', 'dinner'];
