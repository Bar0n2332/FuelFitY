import { UserProfile } from './calculations';

export interface DayLog {
  date: string; // YYYY-MM-DD
  completedMeals: string[]; // meal type keys
  pointsEarned: number;
  menuSeed: number;
}

export interface AppState {
  profile: UserProfile | null;
  totalPoints: number;
  streak: number;
  dayLogs: DayLog[];
  theme: string;
  avatar: string;
  onboardingDone: boolean;
}

const STORAGE_KEY = 'fuelfit_state';

export function getDefaultState(): AppState {
  return {
    profile: null,
    totalPoints: 0,
    streak: 0,
    dayLogs: [],
    theme: 'light',
    avatar: '🐱',
    onboardingDone: false,
  };
}

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return { ...getDefaultState(), ...JSON.parse(raw) };
    }
  } catch (e) {
    console.error('Failed to load state', e);
  }
  return getDefaultState();
}

export function saveState(state: AppState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save state', e);
  }
}

export function getTodayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function getTodayLog(state: AppState): DayLog {
  const today = getTodayKey();
  const existing = state.dayLogs.find(l => l.date === today);
  if (existing) return existing;
  return {
    date: today,
    completedMeals: [],
    pointsEarned: 0,
    menuSeed: Math.floor(Math.random() * 10000),
  };
}

export function calculateStreak(dayLogs: DayLog[]): number {
  if (dayLogs.length === 0) return 0;

  const sorted = [...dayLogs]
    .filter(l => l.completedMeals.length > 0)
    .sort((a, b) => b.date.localeCompare(a.date));

  if (sorted.length === 0) return 0;

  const today = getTodayKey();
  const yesterday = (() => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  })();

  if (sorted[0].date !== today && sorted[0].date !== yesterday) return 0;

  let streak = 1;
  for (let i = 1; i < sorted.length; i++) {
    const prev = new Date(sorted[i - 1].date);
    const curr = new Date(sorted[i].date);
    const diff = (prev.getTime() - curr.getTime()) / (1000 * 60 * 60 * 24);
    if (Math.round(diff) === 1) {
      streak++;
    } else {
      break;
    }
  }
  return streak;
}
