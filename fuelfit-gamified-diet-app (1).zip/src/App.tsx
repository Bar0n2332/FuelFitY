import { useState, useEffect, useCallback, useMemo } from 'react';
import { UserProfile, Goal, Gender, ActivityLevel, calculateTargetCalories, calculateLevel, getPointsForMeal, getStreakBonus, calculateMacros } from './utils/calculations';
import { AppState, loadState, saveState, getTodayLog, getTodayKey, calculateStreak, getDefaultState } from './utils/storage';
import { generateDayMenu, getMealTotalCalories, mealTypeLabels, mealTypeOrder, MealType, MealPlan } from './utils/menuGenerator';
import { getDishMacros, Dish } from './data/meals';

type Theme = 'light' | 'dark' | 'dark-blue' | 'soft-pink' | 'dark-burgundy';

const themeLabels: Record<Theme, string> = {
  'light': '☀️ Светлая',
  'dark': '🌑 Тёмная',
  'dark-blue': '🌊 Тёмно-синяя',
  'soft-pink': '🌸 Розовая',
  'dark-burgundy': '🍷 Бордовая',
};

const themes: Theme[] = ['light', 'dark', 'dark-blue', 'soft-pink', 'dark-burgundy'];

const AVATAR_LIST = [
  '🐱', '🐶', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯',
  '🦁', '🐮', '🐷', '🐸', '🐵', '🐔', '🐧', '🐦',
  '🦄', '🐲', '🦋', '🐢', '🐠', '🦈', '🦉', '🐺',
  '🌟', '💎', '🔥', '⚡', '🎯', '🏆', '🎮', '🎸',
  '🚀', '🌈', '🍀', '🌻', '🎭', '🎪', '👾', '🤖',
];

// Telegram WebApp integration
function useTelegram() {
  useEffect(() => {
    try {
      const tg = (window as any).Telegram?.WebApp;
      if (tg) {
        tg.ready();
        tg.expand();
        tg.enableClosingConfirmation?.();
      }
    } catch (_e) {
      // Not in Telegram context
    }
  }, []);
}

export function App() {
  const [state, setState] = useState<AppState>(loadState);
  const [screen, setScreen] = useState<'onboarding' | 'dashboard' | 'stats' | 'settings'>(() =>
    state.onboardingDone ? 'dashboard' : 'onboarding'
  );
  const [themeMenuOpen, setThemeMenuOpen] = useState(false);
  const [pointsAnimation, setPointsAnimation] = useState<{ points: number; key: number } | null>(null);

  useTelegram();

  const currentTheme = (state.theme || 'light') as Theme;
  const currentAvatar = state.avatar || '🐱';

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', currentTheme);
  }, [currentTheme]);

  useEffect(() => {
    saveState(state);
  }, [state]);

  const setTheme = useCallback((theme: Theme) => {
    setState(prev => ({ ...prev, theme }));
    setThemeMenuOpen(false);
  }, []);

  const setAvatar = useCallback((avatar: string) => {
    setState(prev => ({ ...prev, avatar }));
  }, []);

  const handleOnboardingComplete = useCallback((profile: UserProfile) => {
    setState(prev => ({ ...prev, profile, onboardingDone: true }));
    setScreen('dashboard');
  }, []);

  const todayLog = useMemo(() => getTodayLog(state), [state]);

  const targetCalories = useMemo(() => {
    if (!state.profile) return 2000;
    return calculateTargetCalories(state.profile);
  }, [state.profile]);

  const mealPlan = useMemo(() => {
    return generateDayMenu(targetCalories, todayLog.menuSeed);
  }, [targetCalories, todayLog.menuSeed]);

  const levelInfo = useMemo(() => calculateLevel(state.totalPoints), [state.totalPoints]);

  const handleCompleteMeal = useCallback((mealType: MealType) => {
    const today = getTodayKey();
    const points = getPointsForMeal(mealType);

    setState(prev => {
      const existingLogIndex = prev.dayLogs.findIndex(l => l.date === today);
      const currentLog = existingLogIndex >= 0 ? { ...prev.dayLogs[existingLogIndex] } : {
        date: today,
        completedMeals: [],
        pointsEarned: 0,
        menuSeed: todayLog.menuSeed,
      };

      if (currentLog.completedMeals.includes(mealType)) return prev;

      currentLog.completedMeals = [...currentLog.completedMeals, mealType];
      currentLog.pointsEarned += points;

      let bonusPoints = 0;
      if (currentLog.completedMeals.length === 5) {
        bonusPoints = 30;
      }

      const newLogs = existingLogIndex >= 0
        ? prev.dayLogs.map((l, i) => i === existingLogIndex ? currentLog : l)
        : [...prev.dayLogs, currentLog];

      const newStreak = calculateStreak(newLogs);
      const streakBonus = getStreakBonus(newStreak);
      const totalPointsGained = points + bonusPoints + (currentLog.completedMeals.length === 5 ? streakBonus : 0);

      return {
        ...prev,
        dayLogs: newLogs,
        totalPoints: prev.totalPoints + totalPointsGained,
        streak: newStreak,
      };
    });

    setPointsAnimation({ points, key: Date.now() });
    setTimeout(() => setPointsAnimation(null), 1200);
  }, [todayLog.menuSeed]);

  const handleResetProfile = useCallback(() => {
    setState(prev => ({ ...prev, onboardingDone: false, profile: null }));
    setScreen('onboarding');
  }, []);

  const handleResetProgress = useCallback(() => {
    setState(prev => ({
      ...getDefaultState(),
      profile: prev.profile,
      onboardingDone: prev.onboardingDone,
      theme: prev.theme,
      avatar: prev.avatar,
    }));
  }, []);

  const handleNewMenu = useCallback(() => {
    const today = getTodayKey();
    setState(prev => {
      const newSeed = Math.floor(Math.random() * 10000);
      const existingLogIndex = prev.dayLogs.findIndex(l => l.date === today);
      if (existingLogIndex >= 0) {
        const newLogs = [...prev.dayLogs];
        newLogs[existingLogIndex] = { ...newLogs[existingLogIndex], menuSeed: newSeed, completedMeals: [], pointsEarned: 0 };
        return { ...prev, dayLogs: newLogs };
      }
      return { ...prev, dayLogs: [...prev.dayLogs, { date: today, completedMeals: [], pointsEarned: 0, menuSeed: newSeed }] };
    });
  }, []);

  return (
    <div className="min-h-screen min-h-[100dvh] relative" style={{ backgroundColor: 'var(--bg-main)', color: 'var(--text-primary)' }}>
      {/* Header */}
      <header
        className="sticky top-0 z-50 px-4 py-3 flex items-center justify-between"
        style={{ backgroundColor: 'var(--bg-header)', borderBottom: '1px solid var(--border-color)', boxShadow: `0 1px 3px var(--shadow-color)` }}
      >
        <div className="flex items-center gap-2">
          <span className="text-2xl">🔥</span>
          <h1 className="text-lg font-bold tracking-tight">FuelFit</h1>
        </div>
        <div className="flex items-center gap-2">
          {state.onboardingDone && (
            <div className="flex rounded-lg overflow-hidden" style={{ border: '1px solid var(--border-color)' }}>
              <button
                onClick={() => setScreen('dashboard')}
                className="px-3 py-1.5 text-xs font-medium transition-colors"
                style={{
                  backgroundColor: screen === 'dashboard' ? 'var(--tab-active)' : 'transparent',
                  color: screen === 'dashboard' ? 'white' : 'var(--text-secondary)',
                }}
              >
                Меню
              </button>
              <button
                onClick={() => setScreen('stats')}
                className="px-3 py-1.5 text-xs font-medium transition-colors"
                style={{
                  backgroundColor: screen === 'stats' ? 'var(--tab-active)' : 'transparent',
                  color: screen === 'stats' ? 'white' : 'var(--text-secondary)',
                }}
              >
                Стат
              </button>
              <button
                onClick={() => setScreen('settings')}
                className="px-3 py-1.5 text-xs font-medium transition-colors"
                style={{
                  backgroundColor: screen === 'settings' ? 'var(--tab-active)' : 'transparent',
                  color: screen === 'settings' ? 'white' : 'var(--text-secondary)',
                }}
              >
                ⚙️
              </button>
            </div>
          )}
          <div className="relative">
            <button
              onClick={() => setThemeMenuOpen(!themeMenuOpen)}
              className="w-9 h-9 rounded-full flex items-center justify-center text-lg transition-transform active:scale-90"
              style={{ backgroundColor: 'var(--bg-input)', border: '1px solid var(--border-color)' }}
            >
              🎨
            </button>
            {themeMenuOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setThemeMenuOpen(false)} />
                <div
                  className="absolute right-0 top-full mt-2 z-50 rounded-xl shadow-lg py-1 min-w-[180px] animate-scale-in"
                  style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}
                >
                  {themes.map(t => (
                    <button
                      key={t}
                      onClick={() => setTheme(t)}
                      className="w-full px-4 py-2.5 text-left text-sm flex items-center gap-2 transition-colors"
                      style={{
                        backgroundColor: currentTheme === t ? 'var(--bg-input)' : 'transparent',
                        color: 'var(--text-primary)',
                      }}
                    >
                      {themeLabels[t]}
                      {currentTheme === t && <span className="ml-auto">✓</span>}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Points animation */}
      {pointsAnimation && (
        <div key={pointsAnimation.key} className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[100] pointer-events-none animate-confetti">
          <span className="text-4xl font-bold drop-shadow-lg" style={{ color: 'var(--tab-active)' }}>+{pointsAnimation.points} ⚡</span>
        </div>
      )}

      {/* Content */}
      <main className="pb-8">
        {screen === 'onboarding' && (
          <OnboardingScreen onComplete={handleOnboardingComplete} existingProfile={state.profile} />
        )}
        {screen === 'dashboard' && state.profile && (
          <DashboardScreen
            profile={state.profile}
            mealPlan={mealPlan}
            targetCalories={targetCalories}
            todayLog={todayLog}
            levelInfo={levelInfo}
            totalPoints={state.totalPoints}
            streak={state.streak}
            avatar={currentAvatar}
            onCompleteMeal={handleCompleteMeal}
            onNewMenu={handleNewMenu}
          />
        )}
        {screen === 'stats' && state.profile && (
          <StatsScreen
            profile={state.profile}
            totalPoints={state.totalPoints}
            streak={state.streak}
            levelInfo={levelInfo}
            dayLogs={state.dayLogs}
            targetCalories={targetCalories}
            avatar={currentAvatar}
          />
        )}
        {screen === 'settings' && state.profile && (
          <SettingsScreen
            profile={state.profile}
            avatar={currentAvatar}
            totalPoints={state.totalPoints}
            streak={state.streak}
            dayLogs={state.dayLogs}
            onSetAvatar={setAvatar}
            onResetProfile={handleResetProfile}
            onResetProgress={handleResetProgress}
          />
        )}
      </main>
    </div>
  );
}

/* ==================== ONBOARDING ==================== */

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
  existingProfile: UserProfile | null;
}

function OnboardingScreen({ onComplete, existingProfile }: OnboardingProps) {
  const [step, setStep] = useState(0);
  const [name, setName] = useState(existingProfile?.name || '');
  const [gender, setGender] = useState<Gender>(existingProfile?.gender || 'male');
  const [age, setAge] = useState(existingProfile?.age?.toString() || '');
  const [height, setHeight] = useState(existingProfile?.height?.toString() || '');
  const [weight, setWeight] = useState(existingProfile?.weight?.toString() || '');
  const [goal, setGoal] = useState<Goal>(existingProfile?.goal || 'lose');
  const [activity, setActivity] = useState<ActivityLevel>(existingProfile?.activity || 'light');

  const steps = [
    { title: 'Как тебя зовут?', subtitle: 'Давай познакомимся 👋' },
    { title: 'Расскажи о себе', subtitle: 'Базовые параметры 📊' },
    { title: 'Какая цель?', subtitle: 'Выбери направление 🎯' },
    { title: 'Активность', subtitle: 'Насколько ты активен? 🏃' },
  ];

  const canProceed = () => {
    switch (step) {
      case 0: return name.trim().length >= 2;
      case 1: return age && height && weight && Number(age) > 10 && Number(height) > 100 && Number(weight) > 30;
      case 2: return true;
      case 3: return true;
      default: return false;
    }
  };

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      onComplete({
        name: name.trim(),
        gender,
        age: Number(age),
        height: Number(height),
        weight: Number(weight),
        goal,
        activity,
      });
    }
  };

  const inputStyle: React.CSSProperties = {
    backgroundColor: 'var(--bg-input)',
    border: '2px solid var(--border-color)',
    color: 'var(--text-primary)',
  };

  const activeInputStyle: React.CSSProperties = {
    ...inputStyle,
    borderColor: 'var(--tab-active)',
  };

  return (
    <div className="px-4 pt-8 max-w-md mx-auto">
      {/* Progress */}
      <div className="flex gap-2 mb-8">
        {[0, 1, 2, 3].map(i => (
          <div
            key={i}
            className="h-1.5 flex-1 rounded-full transition-all duration-500"
            style={{ backgroundColor: i <= step ? 'var(--tab-active)' : 'var(--progress-bg)' }}
          />
        ))}
      </div>

      <div className="animate-slide-up" key={step}>
        <h2 className="text-2xl font-bold mb-1">{steps[step].title}</h2>
        <p className="text-sm mb-8" style={{ color: 'var(--text-secondary)' }}>{steps[step].subtitle}</p>

        {step === 0 && (
          <div className="space-y-4">
            <input
              type="text"
              placeholder="Твоё имя..."
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full px-4 py-4 rounded-xl text-lg font-medium outline-none transition-all"
              style={inputStyle}
              autoFocus
              maxLength={20}
            />
            <div className="text-center text-6xl mt-8 animate-bounce-once">
              {name ? '😊' : '👋'}
            </div>
            {name && (
              <p className="text-center text-lg font-medium animate-fade-in">
                Привет, <span style={{ color: 'var(--tab-active)' }}>{name}</span>!
              </p>
            )}
          </div>
        )}

        {step === 1 && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              {([['male', '👨 Мужчина'], ['female', '👩 Женщина']] as const).map(([g, label]) => (
                <button
                  key={g}
                  onClick={() => setGender(g)}
                  className="py-3 rounded-xl font-medium transition-all text-sm"
                  style={gender === g ? { ...activeInputStyle, backgroundColor: 'var(--tab-active-muted)' } : inputStyle}
                >
                  {label}
                </button>
              ))}
            </div>

            <div>
              <label className="text-xs font-medium mb-1 block" style={{ color: 'var(--text-secondary)' }}>Возраст</label>
              <input
                type="number"
                placeholder="25"
                value={age}
                onChange={e => setAge(e.target.value)}
                className="w-full px-4 py-3 rounded-xl outline-none transition-all"
                style={inputStyle}
                min={12}
                max={100}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium mb-1 block" style={{ color: 'var(--text-secondary)' }}>Рост (см)</label>
                <input
                  type="number"
                  placeholder="175"
                  value={height}
                  onChange={e => setHeight(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl outline-none transition-all"
                  style={inputStyle}
                  min={100}
                  max={250}
                />
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block" style={{ color: 'var(--text-secondary)' }}>Вес (кг)</label>
                <input
                  type="number"
                  placeholder="70"
                  value={weight}
                  onChange={e => setWeight(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl outline-none transition-all"
                  style={inputStyle}
                  min={30}
                  max={300}
                />
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-3">
            {([
              ['lose', '🔥 Похудеть', 'Дефицит калорий для сжигания жира'],
              ['maintain', '⚖️ Поддержать вес', 'Удержание текущей формы'],
              ['gain', '💪 Набрать массу', 'Профицит калорий для роста мышц'],
            ] as const).map(([g, label, desc]) => (
              <button
                key={g}
                onClick={() => setGoal(g)}
                className="w-full p-4 rounded-xl text-left transition-all"
                style={goal === g
                  ? { ...activeInputStyle, backgroundColor: 'var(--tab-active-muted)' }
                  : inputStyle
                }
              >
                <div className="font-semibold text-sm">{label}</div>
                <div className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{desc}</div>
              </button>
            ))}
          </div>
        )}

        {step === 3 && (
          <div className="space-y-3">
            {([
              ['sedentary', '🪑 Сидячий', 'Офис, мало движения'],
              ['light', '🚶 Лёгкая', '1-3 тренировки в неделю'],
              ['moderate', '🏃 Средняя', '3-5 тренировок в неделю'],
              ['active', '🏋️ Высокая', '6-7 тренировок в неделю'],
            ] as const).map(([a, label, desc]) => (
              <button
                key={a}
                onClick={() => setActivity(a)}
                className="w-full p-4 rounded-xl text-left transition-all"
                style={activity === a
                  ? { ...activeInputStyle, backgroundColor: 'var(--tab-active-muted)' }
                  : inputStyle
                }
              >
                <div className="font-semibold text-sm">{label}</div>
                <div className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{desc}</div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Buttons */}
      <div className="flex gap-3 mt-8">
        {step > 0 && (
          <button
            onClick={() => setStep(step - 1)}
            className="px-6 py-3 rounded-xl font-medium transition-all active:scale-95"
            style={inputStyle}
          >
            ←
          </button>
        )}
        <button
          onClick={handleNext}
          disabled={!canProceed()}
          className="flex-1 py-3.5 rounded-xl font-semibold text-white transition-all active:scale-[0.97] disabled:opacity-40 disabled:cursor-not-allowed"
          style={{ backgroundColor: canProceed() ? 'var(--tab-active)' : '#9ca3af' }}
        >
          {step === 3 ? '🚀 Начать!' : 'Далее →'}
        </button>
      </div>
    </div>
  );
}

/* ==================== DASHBOARD ==================== */

interface DashboardProps {
  profile: UserProfile;
  mealPlan: MealPlan;
  targetCalories: number;
  todayLog: { date: string; completedMeals: string[]; pointsEarned: number };
  levelInfo: { level: number; title: string; progress: number; pointsInLevel: number; pointsNeeded: number };
  totalPoints: number;
  streak: number;
  avatar: string;
  onCompleteMeal: (mealType: MealType) => void;
  onNewMenu: () => void;
}

function DashboardScreen({
  profile,
  mealPlan,
  targetCalories,
  todayLog,
  levelInfo,
  totalPoints,
  streak,
  avatar,
  onCompleteMeal,
  onNewMenu,
}: DashboardProps) {
  const [expandedMeal, setExpandedMeal] = useState<MealType | null>(null);

  const totalPlanCalories = getMealTotalCalories(mealPlan);
  const completedCount = todayLog.completedMeals.length;
  const totalMeals = 5;
  const dayProgress = completedCount / totalMeals;

  const macros = useMemo(() => calculateMacros(targetCalories, profile.goal), [targetCalories, profile.goal]);

  const goalLabel = profile.goal === 'lose' ? '🔥 Похудение' : profile.goal === 'gain' ? '💪 Набор' : '⚖️ Поддержание';

  const getTimeGreeting = () => {
    const h = new Date().getHours();
    if (h < 6) return 'Доброй ночи';
    if (h < 12) return 'Доброе утро';
    if (h < 18) return 'Добрый день';
    return 'Добрый вечер';
  };

  return (
    <div className="px-4 pt-4 max-w-md mx-auto space-y-4">
      {/* Greeting */}
      <div className="flex items-center gap-3 animate-slide-up">
        <div
          className="w-12 h-12 rounded-full flex items-center justify-center text-2xl shrink-0"
          style={{ backgroundColor: 'var(--bg-card)', border: '2px solid var(--border-color)' }}
        >
          {avatar}
        </div>
        <div>
          <h2 className="text-xl font-bold">{getTimeGreeting()}, {profile.name}!</h2>
          <p className="text-sm mt-0.5" style={{ color: 'var(--text-secondary)' }}>
            {goalLabel} • {targetCalories} ккал/день
          </p>
        </div>
      </div>

      {/* Level & Stats cards */}
      <div className="grid grid-cols-3 gap-2 animate-slide-up" style={{ animationDelay: '0.05s' }}>
        <StatCard emoji="⚡" value={totalPoints.toString()} label="Баллы" />
        <StatCard emoji="🔥" value={`${streak} д.`} label="Серия" />
        <StatCard emoji="🏆" value={`Ур.${levelInfo.level}`} label={levelInfo.title.split(' ')[0]} />
      </div>

      {/* Level progress */}
      <div className="rounded-xl p-3 animate-slide-up" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', animationDelay: '0.1s' }}>
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>
            {levelInfo.title}
          </span>
          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
            {levelInfo.pointsInLevel}/{levelInfo.pointsNeeded} XP
          </span>
        </div>
        <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: 'var(--progress-bg)' }}>
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{ width: `${levelInfo.progress * 100}%`, backgroundColor: 'var(--tab-active)' }}
          />
        </div>
      </div>

      {/* Day progress */}
      <div className="rounded-xl p-4 animate-slide-up" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', animationDelay: '0.15s' }}>
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold">Прогресс дня</span>
          <span className="text-sm font-bold" style={{ color: 'var(--tab-active)' }}>{completedCount}/{totalMeals}</span>
        </div>
        <div className="h-3 rounded-full overflow-hidden mb-3" style={{ backgroundColor: 'var(--progress-bg)' }}>
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{
              width: `${dayProgress * 100}%`,
              backgroundColor: dayProgress >= 1 ? '#f59e0b' : 'var(--tab-active)',
              boxShadow: dayProgress >= 1 ? '0 0 8px #f59e0b' : 'none',
            }}
          />
        </div>
        <div className="flex justify-between text-xs" style={{ color: 'var(--text-muted)' }}>
          <span>~{totalPlanCalories} ккал запланировано</span>
          <span>Б:{macros.protein}г Ж:{macros.fat}г У:{macros.carbs}г</span>
        </div>
        {completedCount === totalMeals && (
          <div className="mt-3 text-center py-2 rounded-lg text-sm font-bold animate-bounce-once" style={{ backgroundColor: 'var(--badge-bg)', color: 'var(--badge-text)' }}>
            🎉 Все приёмы пищи выполнены! +30 бонус
          </div>
        )}
      </div>

      {/* Meal cards */}
      <div className="space-y-2">
        {mealTypeOrder.map((mealType, idx) => {
          const isCompleted = todayLog.completedMeals.includes(mealType);
          const isExpanded = expandedMeal === mealType;
          const items = getMealItems(mealPlan, mealType);
          const points = getPointsForMeal(mealType);

          return (
            <div
              key={mealType}
              className="rounded-xl overflow-hidden transition-all duration-300 animate-slide-up"
              style={{
                backgroundColor: isCompleted ? 'var(--meal-done-bg)' : 'var(--bg-card)',
                border: `1px solid ${isCompleted ? 'var(--meal-done-border)' : 'var(--border-color)'}`,
                animationDelay: `${0.2 + idx * 0.05}s`,
              }}
            >
              <button
                onClick={() => setExpandedMeal(isExpanded ? null : mealType)}
                className="w-full px-4 py-3 flex items-center gap-3 text-left"
              >
                <span className="text-xl">{isCompleted ? '✅' : mealTypeLabels[mealType].split(' ')[0]}</span>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm">{mealTypeLabels[mealType].split(' ').slice(1).join(' ')}</div>
                  <div className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>
                    {items.map(i => i.dish.name).join(', ')}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xs font-bold" style={{ color: isCompleted ? '#059669' : 'var(--text-secondary)' }}>
                    {items.reduce((sum, i) => sum + getDishMacros(i.dish, i.grams).calories, 0)} ккал
                  </div>
                  <div className="text-[10px]" style={{ color: 'var(--text-muted)' }}>+{points} ⚡</div>
                </div>
                <span className="text-xs transition-transform" style={{ transform: isExpanded ? 'rotate(180deg)' : 'none', color: 'var(--text-muted)' }}>▼</span>
              </button>

              {isExpanded && (
                <div className="px-4 pb-3 animate-fade-in">
                  <div className="border-t pt-3 space-y-2" style={{ borderColor: 'var(--border-color)' }}>
                    {items.map((item, i) => {
                      const m = getDishMacros(item.dish, item.grams);
                      return (
                        <div key={i} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span>{item.dish.emoji}</span>
                            <div>
                              <div className="text-sm font-medium">{item.dish.name}</div>
                              <div className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
                                {item.grams}г • Б:{m.protein} Ж:{m.fat} У:{m.carbs}
                              </div>
                            </div>
                          </div>
                          <span className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>{m.calories}</span>
                        </div>
                      );
                    })}

                    {!isCompleted && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onCompleteMeal(mealType);
                        }}
                        className="w-full mt-2 py-2.5 rounded-lg font-semibold text-white text-sm transition-all active:scale-[0.97]"
                        style={{ backgroundColor: 'var(--tab-active)' }}
                      >
                        ✓ Съел! (+{points} ⚡)
                      </button>
                    )}
                    {isCompleted && (
                      <div className="text-center text-sm font-medium py-1" style={{ color: '#059669' }}>
                        ✅ Выполнено
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* New menu button */}
      <button
        onClick={onNewMenu}
        className="w-full py-3 rounded-xl font-medium text-sm transition-all active:scale-[0.97]"
        style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', color: 'var(--text-secondary)' }}
      >
        🔄 Обновить меню
      </button>

      <div className="h-4" />
    </div>
  );
}

function getMealItems(plan: MealPlan, mealType: MealType): { dish: Dish; grams: number }[] {
  switch (mealType) {
    case 'breakfast': return [plan.breakfast];
    case 'snack1': return [plan.snack1];
    case 'lunch': return plan.lunch;
    case 'snack2': return [plan.snack2];
    case 'dinner': return [plan.dinner];
  }
}

function StatCard({ emoji, value, label }: { emoji: string; value: string; label: string }) {
  return (
    <div className="rounded-xl p-3 text-center" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
      <div className="text-lg">{emoji}</div>
      <div className="text-sm font-bold mt-0.5">{value}</div>
      <div className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{label}</div>
    </div>
  );
}

/* ==================== STATS ==================== */

interface StatsProps {
  profile: UserProfile;
  totalPoints: number;
  streak: number;
  levelInfo: { level: number; title: string; progress: number; pointsInLevel: number; pointsNeeded: number };
  dayLogs: { date: string; completedMeals: string[]; pointsEarned: number }[];
  targetCalories: number;
  avatar: string;
}

function StatsScreen({ profile, totalPoints, streak, dayLogs, targetCalories, avatar }: StatsProps) {
  const totalDays = dayLogs.filter(l => l.completedMeals.length > 0).length;
  const perfectDays = dayLogs.filter(l => l.completedMeals.length === 5).length;
  const totalMeals = dayLogs.reduce((sum, l) => sum + l.completedMeals.length, 0);
  const macros = calculateMacros(targetCalories, profile.goal);

  const achievements = [
    { emoji: '🌱', title: 'Первый шаг', desc: 'Завершить первый приём пищи', done: totalMeals >= 1 },
    { emoji: '🔥', title: 'В ритме', desc: 'Серия 3 дня', done: streak >= 3 },
    { emoji: '⭐', title: 'Идеальный день', desc: 'Все 5 приёмов за день', done: perfectDays >= 1 },
    { emoji: '🏆', title: 'Неделя силы', desc: 'Серия 7 дней', done: streak >= 7 },
    { emoji: '💎', title: 'Стабильность', desc: '5 идеальных дней', done: perfectDays >= 5 },
    { emoji: '👑', title: 'Мастер', desc: 'Набрать 1000 баллов', done: totalPoints >= 1000 },
    { emoji: '🏅', title: 'Двухнедельный марафон', desc: 'Серия 14 дней', done: streak >= 14 },
    { emoji: '🌟', title: 'Легенда', desc: '30 дней подряд', done: streak >= 30 },
  ];

  const last7 = (() => {
    const result = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      const log = dayLogs.find(l => l.date === key);
      const dayNames = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
      result.push({
        day: dayNames[d.getDay()],
        count: log?.completedMeals.length || 0,
        date: d.getDate(),
      });
    }
    return result;
  })();

  return (
    <div className="px-4 pt-4 max-w-md mx-auto space-y-4">
      {/* Profile card */}
      <div className="rounded-xl p-5 text-center animate-slide-up" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
        <div className="w-16 h-16 rounded-full mx-auto flex items-center justify-center text-3xl" style={{ backgroundColor: 'var(--tab-active-muted)', border: '3px solid var(--border-color)' }}>
          {avatar}
        </div>
        <h2 className="text-lg font-bold mt-2">{profile.name}</h2>
        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
          {profile.age} лет • {profile.height} см • {profile.weight} кг
        </p>
        <div className="mt-3 flex justify-center gap-4 text-xs" style={{ color: 'var(--text-muted)' }}>
          <span>🎯 {targetCalories} ккал</span>
          <span>Б:{macros.protein}г</span>
          <span>Ж:{macros.fat}г</span>
          <span>У:{macros.carbs}г</span>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-2 animate-slide-up" style={{ animationDelay: '0.05s' }}>
        <div className="rounded-xl p-4" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
          <div className="text-2xl font-bold" style={{ color: 'var(--tab-active)' }}>{totalPoints}</div>
          <div className="text-xs" style={{ color: 'var(--text-muted)' }}>Всего баллов ⚡</div>
        </div>
        <div className="rounded-xl p-4" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
          <div className="text-2xl font-bold text-[#f59e0b]">{streak}</div>
          <div className="text-xs" style={{ color: 'var(--text-muted)' }}>Дней подряд 🔥</div>
        </div>
        <div className="rounded-xl p-4" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
          <div className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>{totalDays}</div>
          <div className="text-xs" style={{ color: 'var(--text-muted)' }}>Активных дней 📅</div>
        </div>
        <div className="rounded-xl p-4" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
          <div className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>{perfectDays}</div>
          <div className="text-xs" style={{ color: 'var(--text-muted)' }}>Идеальных дней ⭐</div>
        </div>
      </div>

      {/* Week chart */}
      <div className="rounded-xl p-4 animate-slide-up" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', animationDelay: '0.1s' }}>
        <h3 className="text-sm font-semibold mb-4">Последние 7 дней</h3>
        <div className="flex items-end justify-between gap-1 h-24">
          {last7.map((d, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full flex flex-col justify-end" style={{ height: '80px' }}>
                <div
                  className="w-full rounded-t-md transition-all duration-500 min-h-[4px]"
                  style={{
                    height: `${Math.max(5, (d.count / 5) * 100)}%`,
                    backgroundColor: d.count === 5 ? '#f59e0b' : d.count > 0 ? 'var(--tab-active)' : 'var(--progress-bg)',
                    opacity: d.count === 0 ? 0.3 : 1,
                  }}
                />
              </div>
              <div className="text-[10px] font-medium" style={{ color: d.count > 0 ? 'var(--text-primary)' : 'var(--text-muted)' }}>{d.day}</div>
              <div className="text-[9px]" style={{ color: 'var(--text-muted)' }}>{d.date}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div className="rounded-xl p-4 animate-slide-up" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', animationDelay: '0.15s' }}>
        <h3 className="text-sm font-semibold mb-3">🏆 Достижения</h3>
        <div className="grid grid-cols-2 gap-2">
          {achievements.map((a, i) => (
            <div
              key={i}
              className="rounded-lg p-3 transition-all"
              style={{
                backgroundColor: a.done ? 'var(--meal-done-bg)' : 'var(--bg-input)',
                border: `1px solid ${a.done ? 'var(--meal-done-border)' : 'var(--border-color)'}`,
                opacity: a.done ? 1 : 0.5,
              }}
            >
              <div className="text-xl mb-1">{a.done ? a.emoji : '🔒'}</div>
              <div className="text-xs font-semibold">{a.title}</div>
              <div className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{a.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="h-4" />
    </div>
  );
}

/* ==================== SETTINGS ==================== */

interface SettingsProps {
  profile: UserProfile;
  avatar: string;
  totalPoints: number;
  streak: number;
  dayLogs: { date: string; completedMeals: string[]; pointsEarned: number }[];
  onSetAvatar: (avatar: string) => void;
  onResetProfile: () => void;
  onResetProgress: () => void;
}

function SettingsScreen({ profile, avatar, totalPoints, streak, dayLogs, onSetAvatar, onResetProfile, onResetProgress }: SettingsProps) {
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);
  const [confirmReset, setConfirmReset] = useState<'none' | 'profile' | 'progress'>('none');

  const totalDays = dayLogs.filter(l => l.completedMeals.length > 0).length;
  const totalMeals = dayLogs.reduce((sum, l) => sum + l.completedMeals.length, 0);

  return (
    <div className="px-4 pt-4 max-w-md mx-auto space-y-4">
      {/* Profile header */}
      <div className="rounded-xl p-5 text-center animate-slide-up" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
        <button
          onClick={() => setShowAvatarPicker(true)}
          className="relative mx-auto block group"
        >
          <div
            className="w-20 h-20 rounded-full flex items-center justify-center text-4xl transition-all group-active:scale-90"
            style={{ backgroundColor: '#10b98120', border: '3px solid var(--border-color)' }}
          >
            {avatar}
          </div>
          <div
            className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center text-xs"
            style={{ backgroundColor: '#10b981', color: 'white', border: '2px solid var(--bg-card)' }}
          >
            ✏️
          </div>
        </button>
        <h2 className="text-lg font-bold mt-3">{profile.name}</h2>
        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
          {profile.gender === 'male' ? '👨' : '👩'} {profile.age} лет • {profile.height} см • {profile.weight} кг
        </p>
        <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
          Нажми на аватарку, чтобы изменить
        </p>
      </div>

      {/* Current stats summary */}
      <div className="rounded-xl p-4 animate-slide-up" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', animationDelay: '0.05s' }}>
        <h3 className="text-sm font-semibold mb-3">📊 Текущий прогресс</h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>⚡ Всего баллов</span>
            <span className="text-sm font-bold text-[#10b981]">{totalPoints}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>🔥 Текущая серия</span>
            <span className="text-sm font-bold text-[#f59e0b]">{streak} дн.</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>📅 Активных дней</span>
            <span className="text-sm font-bold">{totalDays}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>🍽️ Приёмов пищи</span>
            <span className="text-sm font-bold">{totalMeals}</span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="space-y-2 animate-slide-up" style={{ animationDelay: '0.1s' }}>
        <button
          onClick={() => setShowAvatarPicker(true)}
          className="w-full py-3.5 px-4 rounded-xl font-medium text-sm transition-all active:scale-[0.97] text-left flex items-center gap-3"
          style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', color: 'var(--text-primary)' }}
        >
          <span className="text-xl">🎭</span>
          <div>
            <div className="font-semibold">Сменить аватарку</div>
            <div className="text-xs" style={{ color: 'var(--text-muted)' }}>Выбери из 40 иконок</div>
          </div>
          <span className="ml-auto text-2xl">{avatar}</span>
        </button>

        <button
          onClick={() => setConfirmReset('profile')}
          className="w-full py-3.5 px-4 rounded-xl font-medium text-sm transition-all active:scale-[0.97] text-left flex items-center gap-3"
          style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', color: 'var(--text-primary)' }}
        >
          <span className="text-xl">⚙️</span>
          <div>
            <div className="font-semibold">Изменить профиль</div>
            <div className="text-xs" style={{ color: 'var(--text-muted)' }}>Имя, вес, рост, цель</div>
          </div>
        </button>

        <button
          onClick={() => setConfirmReset('progress')}
          className="w-full py-3.5 px-4 rounded-xl font-medium text-sm transition-all active:scale-[0.97] text-left flex items-center gap-3"
          style={{ backgroundColor: 'var(--bg-card)', border: '1px solid #ef444440', color: '#ef4444' }}
        >
          <span className="text-xl">🗑️</span>
          <div>
            <div className="font-semibold">Сбросить прогресс</div>
            <div className="text-xs" style={{ color: 'var(--text-muted)' }}>Обнулить баллы, серию и историю</div>
          </div>
        </button>
      </div>

      {/* Avatar picker modal */}
      {showAvatarPicker && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center" onClick={() => setShowAvatarPicker(false)}>
          <div className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} />
          <div
            className="relative w-full max-w-md rounded-t-2xl p-5 pb-8 animate-slide-up"
            style={{ backgroundColor: 'var(--bg-card)' }}
            onClick={e => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full mx-auto mb-4" style={{ backgroundColor: 'var(--border-color)' }} />
            <h3 className="text-lg font-bold mb-1 text-center">Выбери аватарку</h3>
            <p className="text-xs text-center mb-4" style={{ color: 'var(--text-muted)' }}>Нажми на любую иконку</p>

            {/* Current avatar */}
            <div className="flex justify-center mb-4">
              <div
                className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
                style={{ backgroundColor: '#10b98120', border: '3px solid #10b981' }}
              >
                {avatar}
              </div>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-8 gap-2 max-h-[40vh] overflow-y-auto scrollbar-hide py-1">
              {AVATAR_LIST.map((av) => (
                <button
                  key={av}
                  onClick={() => {
                    onSetAvatar(av);
                    setShowAvatarPicker(false);
                  }}
                  className="w-full aspect-square rounded-xl flex items-center justify-center text-2xl transition-all active:scale-90"
                  style={{
                    backgroundColor: avatar === av ? '#10b98130' : 'var(--bg-input)',
                    border: avatar === av ? '2px solid #10b981' : '1px solid var(--border-color)',
                  }}
                >
                  {av}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Confirm reset modal */}
      {confirmReset !== 'none' && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center px-4" onClick={() => setConfirmReset('none')}>
          <div className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} />
          <div
            className="relative w-full max-w-sm rounded-2xl p-6 animate-scale-in"
            style={{ backgroundColor: 'var(--bg-card)' }}
            onClick={e => e.stopPropagation()}
          >
            <div className="text-center text-4xl mb-3">
              {confirmReset === 'progress' ? '⚠️' : '🔄'}
            </div>
            <h3 className="text-lg font-bold text-center mb-2">
              {confirmReset === 'progress' ? 'Сбросить прогресс?' : 'Изменить профиль?'}
            </h3>
            <p className="text-sm text-center mb-5" style={{ color: 'var(--text-secondary)' }}>
              {confirmReset === 'progress'
                ? 'Все баллы, серия и история будут удалены безвозвратно. Профиль и настройки сохранятся.'
                : 'Вы перейдёте к экрану ввода данных. Прогресс сохранится.'
              }
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setConfirmReset('none')}
                className="flex-1 py-3 rounded-xl font-medium text-sm transition-all active:scale-95"
                style={{ backgroundColor: 'var(--bg-input)', border: '1px solid var(--border-color)', color: 'var(--text-primary)' }}
              >
                Отмена
              </button>
              <button
                onClick={() => {
                  if (confirmReset === 'progress') {
                    onResetProgress();
                  } else {
                    onResetProfile();
                  }
                  setConfirmReset('none');
                }}
                className="flex-1 py-3 rounded-xl font-semibold text-sm text-white transition-all active:scale-95"
                style={{ backgroundColor: confirmReset === 'progress' ? '#ef4444' : '#10b981' }}
              >
                {confirmReset === 'progress' ? '🗑️ Сбросить' : '✏️ Изменить'}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="h-4" />
    </div>
  );
}
